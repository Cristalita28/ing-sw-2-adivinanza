public class JuegoTest {

    public void runTest(){
        testGetIntentos();
    }

    private static void testGetIntentos(){
        Jugador jugador = new Jugador("Sergio");
        if (jugador.getIntentos() == 3) {
            System.out.println("Test testGetIntentos: OK");
        }
        else {
            System.out.println("Test testGetIntentos: No OK");
        }
    }

    private static void testGetNombre(){
        Jugador jugador = new Jugador("Sergio");
        if (jugador.getNombre() == "Sergio"){
            System.out.println("Test testGetNombre: OK");
        }
        else {
            System.out.println("Test testGetNombre: No OK");
        }
    }


}
