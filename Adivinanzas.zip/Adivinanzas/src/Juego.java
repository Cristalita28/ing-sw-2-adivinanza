import java.util.Scanner;
import java.util.Random; //Sirve para generar números aleatorios.

//Clase que controla la lógica del juego.
public class Juego {
    private int numeroSecreto;
    private int limiteIntentos;
    private boolean adivinanza;

    public Juego(int limiteIntentos){ //Constructor para inicializar variables.
        Random aleatorio = new Random(); // Generador de números aleatorios.
        this.numeroSecreto = aleatorio.nextInt(50) + 1; //número secreto entre 1 y 50.
        this.limiteIntentos = limiteIntentos;
        this.adivinanza = false;
    }

    //Lógica principal del juego.
    public void jugar(Jugador jugador){
        Scanner leer = new Scanner(System.in);
        System.out.println("¡Bienvenido "+jugador.getNombre() + "!");
        System.out.println("Intenta adivinar el número entre 1 y 50. Tienes "+ limiteIntentos + " intentos");

        while (!adivinanza && jugador.getIntentos() < limiteIntentos) {
            System.out.print("Ingresa el número: ");
            int intento = leer.nextInt();
            jugador.incrementarIntentos();

            if (intento == numeroSecreto) {
                System.out.println("Felicidades "+ jugador.getNombre() + ", has adivinado en "+ jugador.getIntentos() + " intentos.");
                adivinanza = true; // El jugador acertó.
            }
            else if (intento < numeroSecreto) {
                System.out.println("El número es mayor");
            }
            else {
                System.out.println("El número es menor");
            }

            if (jugador.getIntentos() == limiteIntentos && !adivinanza) { // Si "adivinanza" es false (negación de false = true).
                System.out.println("Eres un perdedor "+ jugador.getNombre() + ". Te quedaste sin intentos, pero el número era "+ numeroSecreto);
            }
        }
        leer.close(); // Cerrar el Scanner.
    }
}
