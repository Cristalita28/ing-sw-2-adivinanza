import java.util.Scanner;

//Clase principal que inicia el juego.
public class Main {
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);

        System.out.print("¡Bienvenido al juego de adivinanzas! \n"+"Ingresa tu nombre: ");
        String nombreJugador = leer.nextLine();

        Jugador jugador = new Jugador(nombreJugador); // Nuevo objeto de la clase Jugador asignado a la variable jugador.

        System.out.print("¿Cuántos intentos deseas tener? ");
        int limiteIntentos = leer.nextInt();

        Juego juego = new Juego(limiteIntentos); // Nuevo objeto de la clase Juego asignado a la variable juego.
        juego.jugar(jugador); // Invocar el metodo jugar con el jugador.

        System.out.println("¡Gracias por jugar, nos vemos pronto!");
        leer.close(); // Cerrar el Scanner.

        /*JuegoTest test = new JuegoTest();
        test.runTest();*/
    }
}
