//Clase que representa al jugador.
public class Jugador {
    private String nombre;
    private int intentos;

    public Jugador (String nombre){ //Constructor para inicializar variables.
        this.nombre = nombre;
        this.intentos = 0;
    }

    // Getter para nombre,
    public String getNombre() {
        return nombre;
    }

    // Getter para intentos.
    public int getIntentos() {
        return intentos;
    }

    //Incrementar intentos.
    public void incrementarIntentos() {
        intentos++;
    }
}
